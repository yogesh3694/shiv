*   Multiple themes are now supported (blue and gray themes)

    *John Wang*

*   You can now instantiate multiple Creditly objects on the same page.

    *John Wang*

*   Removed jQuery as a requirement. Creditly no longer has any requirements!

    *John Wang*
